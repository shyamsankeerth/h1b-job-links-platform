#!/bin/bash

echo "🎨 Starting H1B Job Links Frontend..."

# Navigate to frontend directory
cd frontend

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing frontend dependencies..."
    npm install
fi

# Start the development server
echo "🌟 Starting React app on http://localhost:3000"
npm start
