import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

interface ProfileData {
  user: {
    id: number;
    email: string;
    subscription_type: string;
    subscription_expires_at: string | null;
    is_subscription_active: boolean;
  };
  stats: {
    total_access: number;
    recent_access: number;
  };
}

const Profile: React.FC = () => {
  const { user: currentUser } = useAuth();
  const [profileData, setProfileData] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [upgradeLoading, setUpgradeLoading] = useState(false);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/auth/profile`);
        setProfileData(response.data);
      } catch (error: any) {
        setError(error.response?.data?.error || 'Failed to load profile');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  const handleUpgradeSubscription = async () => {
    setUpgradeLoading(true);
    
    try {
      // For demo purposes, set expiration to 1 year from now
      const expiresAt = new Date();
      expiresAt.setFullYear(expiresAt.getFullYear() + 1);
      
      await axios.post(`${API_BASE_URL}/auth/upgrade-subscription`, {
        subscription_type: 'premium',
        expires_at: expiresAt.toISOString()
      });
      
      // Refresh profile data
      const response = await axios.get(`${API_BASE_URL}/auth/profile`);
      setProfileData(response.data);
    } catch (error: any) {
      setError(error.response?.data?.error || 'Failed to upgrade subscription');
    } finally {
      setUpgradeLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Profile Header */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Profile</h1>
          
          <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
            <div>
              <dt className="text-sm font-medium text-gray-500">Email</dt>
              <dd className="mt-1 text-sm text-gray-900">{profileData?.user.email}</dd>
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Subscription Type</dt>
              <dd className="mt-1">
                <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                  profileData?.user.is_subscription_active 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-red-100 text-red-800'
                }`}>
                  {profileData?.user.subscription_type}
                </span>
              </dd>
            </div>
            
            {profileData?.user.subscription_expires_at && (
              <div>
                <dt className="text-sm font-medium text-gray-500">Subscription Expires</dt>
                <dd className="mt-1 text-sm text-gray-900">
                  {new Date(profileData.user.subscription_expires_at).toLocaleDateString()}
                </dd>
              </div>
            )}
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Account Status</dt>
              <dd className="mt-1">
                <span className={`inline-flex px-2 py-1 text-xs font-semibold rounded-full ${
                  profileData?.user.is_subscription_active 
                    ? 'bg-green-100 text-green-800' 
                    : 'bg-yellow-100 text-yellow-800'
                }`}>
                  {profileData?.user.is_subscription_active ? 'Active' : 'Inactive'}
                </span>
              </dd>
            </div>
          </dl>
        </div>
      </div>

      {/* Usage Statistics */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Usage Statistics
          </h3>
          
          <dl className="grid grid-cols-1 gap-x-4 gap-y-6 sm:grid-cols-2">
            <div>
              <dt className="text-sm font-medium text-gray-500">Total Link Accesses</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">
                {profileData?.stats.total_access || 0}
              </dd>
            </div>
            
            <div>
              <dt className="text-sm font-medium text-gray-500">Recent Accesses (7 days)</dt>
              <dd className="mt-1 text-3xl font-semibold text-gray-900">
                {profileData?.stats.recent_access || 0}
              </dd>
            </div>
          </dl>
        </div>
      </div>

      {/* Subscription Management */}
      {!profileData?.user.is_subscription_active && (
        <div className="bg-white shadow rounded-lg">
          <div className="px-4 py-5 sm:p-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
              Upgrade Subscription
            </h3>
            <p className="text-sm text-gray-600 mb-4">
              Upgrade to premium to access all job links and features.
            </p>
            
            <button
              onClick={handleUpgradeSubscription}
              disabled={upgradeLoading}
              className="btn-primary disabled:opacity-50"
            >
              {upgradeLoading ? 'Upgrading...' : 'Upgrade to Premium'}
            </button>
          </div>
        </div>
      )}

      {/* Account Information */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            About Your Account
          </h3>
          <div className="text-sm text-gray-600 space-y-2">
            <p>
              Your account gives you access to curated H1B job opportunities across various roles and companies.
            </p>
            <p>
              All job links are hand-picked and regularly updated to ensure quality and relevance.
            </p>
            <p>
              Your usage statistics help us understand which opportunities are most valuable to you.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
