import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

interface JobLink {
  id: number;
  title: string;
  company: string;
  url: string;
  location: string | null;
  salary_range: string | null;
  date_added: string;
  role_name: string;
}

type TabType = 'sponsored' | 'f1';

const JobLinks: React.FC = () => {
  const { roleId } = useParams<{ roleId: string }>();
  const { user } = useAuth();
  const [links, setLinks] = useState<JobLink[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [accessingLink, setAccessingLink] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('sponsored');

  const fetchLinks = async (type: TabType) => {
    if (!roleId) return;
    
    try {
      setLoading(true);
      const response = await axios.get(`${API_BASE_URL}/jobs/roles/${roleId}/links`, {
        params: { type }
      });
      setLinks(response.data.links);
    } catch (error: any) {
      setError(error.response?.data?.error || 'Failed to load job links');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLinks(activeTab);
  }, [roleId, activeTab]);

  const handleLinkAccess = async (linkId: number, url: string) => {
    setAccessingLink(linkId);
    
    try {
      // Log the access
      await axios.post(`${API_BASE_URL}/jobs/links/${linkId}/access`);
      
      // Open the link in a new tab
      window.open(url, '_blank');
    } catch (error: any) {
      console.error('Failed to log access:', error);
    } finally {
      setAccessingLink(null);
    }
  };


  if (loading) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '16rem' }}>
        <div style={{ 
          border: '4px solid #f3f3f3',
          borderTop: '4px solid #2563eb',
          borderRadius: '50%',
          width: '8rem',
          height: '8rem',
          animation: 'spin 1s linear infinite'
        }}></div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <Link to="/" style={{ display: 'inline-flex', alignItems: 'center', color: '#2563eb', textDecoration: 'none' }}>
          <span style={{ marginRight: '0.25rem' }}>←</span>
          Back to Dashboard
        </Link>
        <div style={{ 
          backgroundColor: '#fef2f2', 
          border: '1px solid #fecaca', 
          color: '#dc2626', 
          padding: '1rem', 
          borderRadius: '0.375rem' 
        }}>
          {error}
        </div>
      </div>
    );
  }

  if (!user?.is_subscription_active) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        <Link to="/" style={{ display: 'inline-flex', alignItems: 'center', color: '#2563eb', textDecoration: 'none' }}>
          <span style={{ marginRight: '0.25rem' }}>←</span>
          Back to Dashboard
        </Link>
        <div style={{ 
          backgroundColor: '#fef3c7', 
          border: '1px solid #fde68a', 
          color: '#92400e', 
          padding: '1rem', 
          borderRadius: '0.375rem' 
        }}>
          <p style={{ fontSize: '0.875rem', margin: 0 }}>
            Your subscription is inactive. Please upgrade to access job links.
          </p>
        </div>
      </div>
    );
  }


  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      {/* Header */}
      <div style={{ backgroundColor: 'white', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '0.5rem' }}>
        <div style={{ padding: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <div>
              <Link to="/" style={{ display: 'inline-flex', alignItems: 'center', color: '#2563eb', textDecoration: 'none', marginBottom: '0.5rem' }}>
                <span style={{ marginRight: '0.25rem' }}>←</span>
                Back to Dashboard
              </Link>
              <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#111827', margin: 0 }}>
                {links[0]?.role_name || 'Job Links'}
              </h1>
              <p style={{ color: '#6b7280', margin: '0.5rem 0 0 0' }}>
                Curated opportunities with verified visa sponsorship information
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ backgroundColor: 'white', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '0.5rem' }}>
        <div style={{ borderBottom: '1px solid #e5e7eb' }}>
          <div style={{ display: 'flex', padding: '0 1.5rem' }}>
            <button
              onClick={() => setActiveTab('sponsored')}
              style={{
                padding: '1rem 0',
                marginRight: '2rem',
                borderBottom: '2px solid',
                borderColor: activeTab === 'sponsored' ? '#2563eb' : 'transparent',
                color: activeTab === 'sponsored' ? '#2563eb' : '#6b7280',
                fontWeight: activeTab === 'sponsored' ? '600' : '500',
                fontSize: '0.875rem',
                backgroundColor: 'transparent',
                borderTop: 'none',
                borderLeft: 'none',
                borderRight: 'none',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center'
              }}
            >
              <span style={{ marginRight: '0.5rem' }}>🏆</span>
              H1B Sponsored Jobs
            </button>
            
            <button
              onClick={() => setActiveTab('f1')}
              style={{
                padding: '1rem 0',
                borderBottom: '2px solid',
                borderColor: activeTab === 'f1' ? '#2563eb' : 'transparent',
                color: activeTab === 'f1' ? '#2563eb' : '#6b7280',
                fontWeight: activeTab === 'f1' ? '600' : '500',
                fontSize: '0.875rem',
                backgroundColor: 'transparent',
                borderTop: 'none',
                borderLeft: 'none',
                borderRight: 'none',
                cursor: 'pointer',
                display: 'flex',
                alignItems: 'center'
              }}
            >
              <span style={{ marginRight: '0.5rem' }}>🎓</span>
              F1 Visa Eligible Jobs
            </button>
          </div>
        </div>

        {/* Tab Content */}
        <div style={{ padding: '1.5rem' }}>
          {activeTab === 'sponsored' && (
            <div>
              <div style={{ 
                backgroundColor: '#f0f9ff', 
                border: '1px solid #bae6fd', 
                borderRadius: '0.5rem', 
                padding: '1rem', 
                marginBottom: '1.5rem' 
              }}>
                <h3 style={{ color: '#0369a1', fontSize: '0.875rem', fontWeight: '600', margin: '0 0 0.5rem 0' }}>
                  🏆 H1B Sponsored Jobs
                </h3>
                <p style={{ color: '#0369a1', fontSize: '0.875rem', margin: 0 }}>
                  Companies that explicitly sponsor H1B visas. These are verified opportunities where you can work long-term in the US.
                </p>
              </div>
            </div>
          )}

          {activeTab === 'f1' && (
            <div>
              <div style={{ 
                backgroundColor: '#fef3c7', 
                border: '1px solid #fde68a', 
                borderRadius: '0.5rem', 
                padding: '1rem', 
                marginBottom: '1.5rem' 
              }}>
                <h3 style={{ color: '#92400e', fontSize: '0.875rem', fontWeight: '600', margin: '0 0 0.5rem 0' }}>
                  🎓 F1 Visa Eligible Jobs
                </h3>
                <p style={{ color: '#92400e', fontSize: '0.875rem', margin: 0 }}>
                  Companies that hire F1 students for OPT/CPT opportunities. Great for gaining experience and potentially converting to H1B.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Job Links Grid */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
        {links.map((link) => (
          <div key={link.id} style={{ backgroundColor: 'white', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '0.5rem' }}>
            <div style={{ padding: '1.5rem' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between' }}>
                <div style={{ flex: 1 }}>
                  <h3 style={{ fontSize: '1.125rem', fontWeight: '500', color: '#111827', marginBottom: '0.5rem', margin: 0 }}>
                    {link.title}
                  </h3>
                  <p style={{ fontSize: '0.875rem', fontWeight: '500', color: '#2563eb', marginBottom: '0.75rem' }}>
                    {link.company}
                  </p>
                  
                  <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', fontSize: '0.875rem', color: '#6b7280', marginBottom: '1rem' }}>
                    {link.location && (
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <span style={{ marginRight: '0.25rem' }}>📍</span>
                        {link.location}
                      </div>
                    )}
                    {link.salary_range && (
                      <div style={{ display: 'flex', alignItems: 'center' }}>
                        <span style={{ marginRight: '0.25rem' }}>💰</span>
                        {link.salary_range}
                      </div>
                    )}
                    <div style={{ display: 'flex', alignItems: 'center' }}>
                      Added {new Date(link.date_added).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                
                <div style={{ marginLeft: '1rem', flexShrink: 0 }}>
                  <button
                    onClick={() => handleLinkAccess(link.id, link.url)}
                    disabled={accessingLink === link.id}
                    style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      padding: '0.5rem 1rem',
                      border: '1px solid transparent',
                      fontSize: '0.875rem',
                      fontWeight: '500',
                      borderRadius: '0.375rem',
                      color: 'white',
                      backgroundColor: '#2563eb',
                      cursor: 'pointer',
                      opacity: accessingLink === link.id ? 0.5 : 1
                    }}
                  >
                    {accessingLink === link.id ? (
                      <>
                        <div style={{ 
                          border: '2px solid #f3f3f3',
                          borderTop: '2px solid white',
                          borderRadius: '50%',
                          width: '1rem',
                          height: '1rem',
                          animation: 'spin 1s linear infinite',
                          marginRight: '0.5rem'
                        }}></div>
                        Opening...
                      </>
                    ) : (
                      <>
                        <span style={{ marginRight: '0.5rem' }}>🔗</span>
                        View Job
                      </>
                    )}
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {links.length === 0 && (
        <div style={{ backgroundColor: 'white', boxShadow: '0 1px 3px rgba(0,0,0,0.1)', borderRadius: '0.5rem' }}>
          <div style={{ padding: '1.5rem', textAlign: 'center' }}>
            <p style={{ color: '#6b7280', margin: 0 }}>
              No {activeTab === 'sponsored' ? 'H1B sponsored' : 'F1 visa eligible'} job links found for this role.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};

export default JobLinks;