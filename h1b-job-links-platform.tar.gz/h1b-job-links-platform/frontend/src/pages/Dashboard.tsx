import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import axios from 'axios';
// Using simple text/icons instead of Heroicons

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

interface Role {
  id: number;
  name: string;
  link_count: number;
}

interface DashboardStats {
  total_links: number;
  total_roles: number;
  user_stats: {
    total_access: number;
    recent_access: number;
  };
  all_roles: Role[];
  top_roles: Role[];
}

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [selectedRoleId, setSelectedRoleId] = useState<string>('');

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const response = await axios.get(`${API_BASE_URL}/jobs/dashboard`);
        setStats(response.data);
      } catch (error: any) {
        setError(error.response?.data?.error || 'Failed to load dashboard');
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const handleRoleSelect = (roleId: string) => {
    if (roleId) {
      navigate(`/jobs/${roleId}`);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
        {error}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-white overflow-hidden shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h1 className="text-2xl font-bold text-gray-900">
            Welcome back, {user?.email}!
          </h1>
          <p className="mt-2 text-gray-600">
            Access your curated H1B job opportunities. You have {stats?.user_stats.total_access || 0} total link accesses.
          </p>
          {!user?.is_subscription_active && (
            <div className="mt-4 bg-yellow-50 border border-yellow-200 text-yellow-700 px-4 py-3 rounded-md">
              <p className="text-sm">
                Your subscription is inactive. Please upgrade to access job links.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span style={{ fontSize: '1.5rem' }}>💼</span>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Total Job Links
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {stats?.total_links.toLocaleString() || 0}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span style={{ fontSize: '1.5rem' }}>📊</span>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Job Roles
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {stats?.total_roles || 0}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <span style={{ fontSize: '1.5rem' }}>🕒</span>
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Recent Access (7 days)
                  </dt>
                  <dd className="text-lg font-medium text-gray-900">
                    {stats?.user_stats.recent_access || 0}
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Role Selection Dropdown */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900 mb-4">
            Select a Job Role ({stats?.all_roles.length || 0} roles available)
          </h3>
          <div className="space-y-4">
            <div>
              <label htmlFor="role-select" className="block text-sm font-medium text-gray-700 mb-2">
                Choose your role to view relevant job opportunities:
              </label>
              <select
                id="role-select"
                value={selectedRoleId}
                onChange={(e) => {
                  setSelectedRoleId(e.target.value);
                  handleRoleSelect(e.target.value);
                }}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-base"
                style={{ 
                  backgroundImage: `url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e")`,
                  backgroundPosition: 'right 0.5rem center',
                  backgroundRepeat: 'no-repeat',
                  backgroundSize: '1.5em 1.5em',
                  paddingRight: '2.5rem'
                }}
              >
                <option value="">Select a job role...</option>
                {stats?.all_roles
                  .sort((a, b) => a.name.localeCompare(b.name))
                  .map((role) => (
                    <option key={role.id} value={role.id}>
                      {role.name}
                    </option>
                  ))}
              </select>
            </div>
            
            {/* Quick Access to Popular Roles */}
            <div>
              <p className="text-sm text-gray-600 mb-3">Popular roles:</p>
              <div className="flex flex-wrap gap-2">
                {stats?.top_roles.slice(0, 6).map((role) => (
                  <Link
                    key={role.id}
                    to={`/jobs/${role.id}`}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    {role.name}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
