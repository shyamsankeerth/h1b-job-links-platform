import { Response } from 'express';
import { JobLinkModel } from '../models/JobLink';
import { AuthRequest } from '../middleware/auth';

export class JobController {
  static async getAllRoles(req: AuthRequest, res: Response) {
    try {
      const roles = await JobLinkModel.getRolesWithCounts();
      res.json({ roles });
    } catch (error) {
      console.error('Get roles error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async getLinksByRole(req: AuthRequest, res: Response) {
    try {
      const { roleId } = req.params;
      const { page = 1, limit = 20, type } = req.query; // type: 'sponsored' or 'f1'

      const offset = (Number(page) - 1) * Number(limit);
      const jobType = type as 'sponsored' | 'f1' | undefined;
      const links = await JobLinkModel.findByRole(Number(roleId), Number(limit), offset, jobType);

      res.json({
        links,
        pagination: {
          page: Number(page),
          limit: Number(limit),
          total: links.length
        }
      });
    } catch (error) {
      console.error('Get links by role error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async searchLinks(req: AuthRequest, res: Response) {
    try {
      const { search, roleId } = req.query;
      
      const links = await JobLinkModel.searchLinks(
        search as string || '',
        roleId ? Number(roleId) : undefined
      );

      res.json({ links });
    } catch (error) {
      console.error('Search links error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async accessLink(req: AuthRequest, res: Response) {
    try {
      const { linkId } = req.params;

      // Log the access
      await JobLinkModel.logAccess(req.user!.id, Number(linkId));

      // Get the link details
      const link = await JobLinkModel.findById(Number(linkId));
      if (!link) {
        return res.status(404).json({ error: 'Link not found' });
      }

      res.json({
        message: 'Link access logged',
        link: {
          id: link.id,
          title: link.title,
          company: link.company,
          url: link.url,
          location: link.location,
          salary_range: link.salary_range
        }
      });
    } catch (error) {
      console.error('Access link error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async getDashboardStats(req: AuthRequest, res: Response) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: 'User not authenticated' });
      }

      const totalLinks = await JobLinkModel.getTotalLinks();
      const roles = await JobLinkModel.getRolesWithCounts();
      const userStats = await JobLinkModel.getUserAccessStats(req.user.id);

      res.json({
        total_links: totalLinks,
        total_roles: roles.length,
        user_stats: userStats,
        all_roles: roles
          .sort((a, b) => b.link_count - a.link_count),
        top_roles: roles
          .sort((a, b) => b.link_count - a.link_count)
          .slice(0, 10)
      });
    } catch (error) {
      console.error('Get dashboard stats error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
}
