import { Request, Response } from 'express';
import { UserModel } from '../models/User';
import { generateToken, AuthRequest } from '../middleware/auth';

export class AuthController {
  static async register(req: Request, res: Response) {
    try {
      const { email, password, subscription_type } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
      }

      // Check if user already exists
      const existingUser = await UserModel.findByEmail(email);
      if (existingUser) {
        return res.status(400).json({ error: 'User already exists with this email' });
      }

      // Create user
      const user = await UserModel.create({
        email,
        password,
        subscription_type: subscription_type || 'basic'
      });

      // Generate token
      const token = generateToken(user.id);

      res.status(201).json({
        message: 'User registered successfully',
        token,
        user: {
          id: user.id,
          email: user.email,
          subscription_type: user.subscription_type
        }
      });
    } catch (error) {
      console.error('Registration error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async login(req: Request, res: Response) {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: 'Email and password are required' });
      }

      // Find user
      const user = await UserModel.findByEmail(email);
      if (!user) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      // Validate password
      const isValidPassword = await UserModel.validatePassword(user, password);
      if (!isValidPassword) {
        return res.status(401).json({ error: 'Invalid credentials' });
      }

      // Generate token
      const token = generateToken(user.id);

      res.json({
        message: 'Login successful',
        token,
        user: {
          id: user.id,
          email: user.email,
          subscription_type: user.subscription_type
        }
      });
    } catch (error) {
      console.error('Login error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async getProfile(req: AuthRequest, res: Response) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: 'User not authenticated' });
      }

      const user = await UserModel.findById(req.user.id);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      const isSubscriptionActive = await UserModel.isSubscriptionActive(user.id);
      const accessStats = await require('../models/JobLink').JobLinkModel.getUserAccessStats(user.id);

      res.json({
        user: {
          id: user.id,
          email: user.email,
          subscription_type: user.subscription_type,
          subscription_expires_at: user.subscription_expires_at,
          is_subscription_active: isSubscriptionActive
        },
        stats: accessStats
      });
    } catch (error) {
      console.error('Get profile error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }

  static async upgradeSubscription(req: AuthRequest, res: Response) {
    try {
      if (!req.user) {
        return res.status(401).json({ error: 'User not authenticated' });
      }

      const { subscription_type, expires_at } = req.body;

      if (!subscription_type || !expires_at) {
        return res.status(400).json({ error: 'Subscription type and expiration date are required' });
      }

      await UserModel.updateSubscription(req.user.id, subscription_type, expires_at);

      res.json({
        message: 'Subscription upgraded successfully',
        subscription_type,
        expires_at
      });
    } catch (error) {
      console.error('Subscription upgrade error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  }
}
