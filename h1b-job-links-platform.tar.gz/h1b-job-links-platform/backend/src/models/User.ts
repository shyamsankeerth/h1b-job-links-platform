import { database } from './database';
import bcrypt from 'bcryptjs';

const db = database;

export interface User {
  id: number;
  email: string;
  password_hash: string;
  subscription_type: string;
  subscription_expires_at: string;
  created_at: string;
  updated_at: string;
}

export interface CreateUserData {
  email: string;
  password: string;
  subscription_type?: string;
}

export class UserModel {
  static async create(userData: CreateUserData): Promise<User> {
    const saltRounds = 10;
    const password_hash = await bcrypt.hash(userData.password, saltRounds);
    
    const result = await db.run(
      'INSERT INTO users (email, password_hash, subscription_type) VALUES (?, ?, ?)',
      [userData.email, password_hash, userData.subscription_type || 'basic']
    );

    const user = await this.findById(result.lastID);
    if (!user) {
      throw new Error('Failed to create user');
    }
    return user;
  }

  static async findById(id: number): Promise<User | null> {
    const user = await db.get('SELECT * FROM users WHERE id = ?', [id]);
    return user as User | null;
  }

  static async findByEmail(email: string): Promise<User | null> {
    const user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
    return user as User | null;
  }

  static async validatePassword(user: User, password: string): Promise<boolean> {
    return bcrypt.compare(password, user.password_hash);
  }

  static async updateSubscription(userId: number, subscriptionType: string, expiresAt: string): Promise<void> {
    await db.run(
      'UPDATE users SET subscription_type = ?, subscription_expires_at = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?',
      [subscriptionType, expiresAt, userId]
    );
  }

  static async isSubscriptionActive(userId: number): Promise<boolean> {
    const user = await db.get(
      'SELECT subscription_expires_at FROM users WHERE id = ?',
      [userId]
    ) as any;

    if (!user || !user.subscription_expires_at) {
      return false;
    }

    const expirationDate = new Date(user.subscription_expires_at);
    return expirationDate > new Date();
  }

  static async getAllUsers(): Promise<User[]> {
    const users = await db.all('SELECT * FROM users ORDER BY created_at DESC');
    return users as User[];
  }
}