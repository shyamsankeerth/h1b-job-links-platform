import sqlite3 from 'sqlite3';
import path from 'path';

const dbPath = path.join(__dirname, '../../data/job_links.db');

export class Database {
  private db: sqlite3.Database;

  constructor() {
    this.db = new sqlite3.Database(dbPath);
    this.initializeTables();
  }

  private async initializeTables() {
    // Users table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        subscription_type TEXT DEFAULT 'basic',
        subscription_expires_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Job roles table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS job_roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT UNIQUE NOT NULL,
        description TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Job links table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS job_links (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        company TEXT NOT NULL,
        url TEXT NOT NULL,
        role_id INTEGER NOT NULL,
        date_added DATETIME DEFAULT CURRENT_TIMESTAMP,
        is_active BOOLEAN DEFAULT 1,
        source TEXT,
        location TEXT,
        salary_range TEXT,
        job_type TEXT DEFAULT 'sponsored',
        FOREIGN KEY (role_id) REFERENCES job_roles (id)
      )
    `);

    // Link access logs
    this.db.run(`
      CREATE TABLE IF NOT EXISTS link_access_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        link_id INTEGER NOT NULL,
        accessed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users (id),
        FOREIGN KEY (link_id) REFERENCES job_links (id)
      )
    `);

    // Insert default job roles
    this.insertDefaultRoles();
  }

  private insertDefaultRoles() {
    const defaultRoles = [
      'Data Analyst', 'Business Analyst', 'Software Engineer', 'Java Developer',
      'Python Developer', 'Full Stack Developer', 'Frontend Developer', 'Backend Developer',
      'DevOps Engineer', 'Data Scientist', 'Machine Learning Engineer', 'Product Manager',
      'Project Manager', 'UX Designer', 'UI Designer', 'Marketing Manager',
      'Sales Manager', 'Financial Analyst', 'HR Manager', 'Operations Manager',
      'System Administrator', 'Network Engineer', 'Database Administrator', 'QA Engineer',
      'Mobile Developer', 'iOS Developer', 'Android Developer', 'React Developer',
      'Angular Developer', 'Vue.js Developer', 'Node.js Developer', 'PHP Developer',
      'C# Developer', '.NET Developer', 'Ruby Developer', 'Go Developer',
      'Rust Developer', 'Cloud Engineer', 'Cybersecurity Analyst', 'IT Support Specialist'
    ];

    for (const role of defaultRoles) {
      this.db.run('INSERT OR IGNORE INTO job_roles (name) VALUES (?)', [role]);
    }
  }

  getDb() {
    return this.db;
  }

  close() {
    this.db.close();
  }

  // Promise-based methods
  run(sql: string, params: any[] = []): Promise<any> {
    return new Promise((resolve, reject) => {
      this.db.run(sql, params, function(err) {
        if (err) {
          reject(err);
        } else {
          resolve({ lastID: this.lastID, changes: this.changes });
        }
      });
    });
  }

  get(sql: string, params: any[] = []): Promise<any> {
    return new Promise((resolve, reject) => {
      this.db.get(sql, params, (err, row) => {
        if (err) {
          reject(err);
        } else {
          resolve(row);
        }
      });
    });
  }

  all(sql: string, params: any[] = []): Promise<any[]> {
    return new Promise((resolve, reject) => {
      this.db.all(sql, params, (err, rows) => {
        if (err) {
          reject(err);
        } else {
          resolve(rows);
        }
      });
    });
  }
}

export const database = new Database();