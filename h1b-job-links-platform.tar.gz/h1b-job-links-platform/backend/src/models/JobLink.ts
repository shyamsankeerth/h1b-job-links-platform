import { database } from './database';

const db = database;

export interface JobRole {
  id: number;
  name: string;
  description: string | null;
  created_at: string;
}

export interface JobLink {
  id: number;
  title: string;
  company: string;
  url: string;
  role_id: number;
  date_added: string;
  is_active: boolean;
  source: string | null;
  job_type: string;
  location: string | null;
  salary_range: string | null;
}

export interface JobLinkWithRole extends JobLink {
  role_name: string;
}

export interface CreateJobLinkData {
  title: string;
  company: string;
  url: string;
  role_id: number;
  source?: string;
  location?: string;
  salary_range?: string;
  job_type?: string;
}

export class JobLinkModel {
  static async create(linkData: CreateJobLinkData): Promise<JobLink> {
    const result = await db.run(
      'INSERT INTO job_links (title, company, url, role_id, source, location, salary_range, job_type) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [
        linkData.title,
        linkData.company,
        linkData.url,
        linkData.role_id,
        linkData.source || null,
        linkData.location || null,
        linkData.salary_range || null,
        linkData.job_type || 'sponsored'
      ]
    );

    const link = await this.findById(result.lastID);
    if (!link) {
      throw new Error('Failed to create job link');
    }
    return link;
  }

  static async findById(id: number): Promise<JobLink | null> {
    const link = await db.get('SELECT * FROM job_links WHERE id = ?', [id]);
    return link as JobLink | null;
  }

  static async findByRole(roleId: number, limit: number = 50, offset: number = 0, jobType?: 'sponsored' | 'f1'): Promise<JobLinkWithRole[]> {
    let whereClause = 'jl.role_id = ? AND jl.is_active = 1';
    const params: any[] = [roleId];

    // Add job type filtering
    if (jobType === 'sponsored') {
      whereClause += ' AND jl.job_type = ?';
      params.push('sponsored');
    } else if (jobType === 'f1') {
      whereClause += ' AND jl.job_type = ?';
      params.push('f1');
    }

    params.push(limit, offset);

    const links = await db.all(`
      SELECT jl.*, jr.name as role_name 
      FROM job_links jl
      JOIN job_roles jr ON jl.role_id = jr.id
      WHERE ${whereClause}
      ORDER BY jl.date_added DESC
      LIMIT ? OFFSET ?
    `, params);

    return links as JobLinkWithRole[];
  }

  static async getAllRoles(): Promise<JobRole[]> {
    const roles = await db.all('SELECT * FROM job_roles ORDER BY name');
    return roles as JobRole[];
  }

  static async getRolesWithCounts(): Promise<(JobRole & { link_count: number })[]> {
    const roles = await db.all(`
      SELECT jr.*, COUNT(jl.id) as link_count
      FROM job_roles jr
      LEFT JOIN job_links jl ON jr.id = jl.role_id AND jl.is_active = 1
      GROUP BY jr.id
      ORDER BY jr.name
    `);

    return roles as (JobRole & { link_count: number })[];
  }

  static async searchLinks(searchTerm: string, roleId?: number): Promise<JobLinkWithRole[]> {
    let query = `
      SELECT jl.*, jr.name as role_name 
      FROM job_links jl
      JOIN job_roles jr ON jl.role_id = jr.id
      WHERE jl.is_active = 1
    `;
    
    const params: any[] = [];

    if (searchTerm) {
      query += ` AND (jl.title LIKE ? OR jl.company LIKE ?)`;
      params.push(`%${searchTerm}%`, `%${searchTerm}%`);
    }

    if (roleId) {
      query += ` AND jl.role_id = ?`;
      params.push(roleId);
    }

    query += ` ORDER BY jl.date_added DESC LIMIT 100`;

    const links = await db.all(query, params);
    return links as JobLinkWithRole[];
  }

  static async logAccess(userId: number, linkId: number): Promise<void> {
    await db.run(
      'INSERT INTO link_access_logs (user_id, link_id) VALUES (?, ?)',
      [userId, linkId]
    );
  }

  static async getUserAccessStats(userId: number): Promise<{ total_access: number; recent_access: number }> {
    const totalResult = await db.get(
      'SELECT COUNT(*) as count FROM link_access_logs WHERE user_id = ?',
      [userId]
    );

    const recentResult = await db.get(
      'SELECT COUNT(*) as count FROM link_access_logs WHERE user_id = ? AND accessed_at >= datetime("now", "-7 days")',
      [userId]
    );

    return {
      total_access: (totalResult as any).count,
      recent_access: (recentResult as any).count
    };
  }

  static async bulkCreate(links: CreateJobLinkData[]): Promise<void> {
    for (const link of links) {
      await this.create(link);
    }
  }

  static async getTotalLinks(): Promise<number> {
    const result = await db.get('SELECT COUNT(*) as count FROM job_links WHERE is_active = 1');
    return (result as any).count;
  }
}