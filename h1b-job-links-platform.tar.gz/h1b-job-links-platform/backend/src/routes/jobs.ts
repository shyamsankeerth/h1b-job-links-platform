import { Router } from 'express';
import { JobController } from '../controllers/jobController';
import { authenticateToken, requireActiveSubscription } from '../middleware/auth';

const router = Router();

// All job routes require authentication
router.use(authenticateToken);

// Routes that require active subscription
router.get('/roles', JobController.getAllRoles);
router.get('/roles/:roleId/links', requireActiveSubscription, JobController.getLinksByRole);
router.get('/search', requireActiveSubscription, JobController.searchLinks);
router.post('/links/:linkId/access', requireActiveSubscription, JobController.accessLink);
router.get('/dashboard', JobController.getDashboardStats);

export default router;
