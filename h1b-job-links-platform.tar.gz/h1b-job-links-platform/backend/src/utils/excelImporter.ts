import * as XLSX from 'xlsx';
import { JobLinkModel, CreateJobLinkData } from '../models/JobLink';
import { database } from '../models/database';

const db = database;

export class ExcelImporter {
  static async importFromExcel(filePath: string): Promise<{ imported: number; errors: string[] }> {
    try {
      // Read the Excel file
      const workbook = XLSX.readFile(filePath);
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      
      // Convert to JSON
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      const errors: string[] = [];
      let imported = 0;

      for (const row of jsonData) {
        try {
          const jobLinkData = await this.parseRow(row);
          if (jobLinkData) {
            await JobLinkModel.create(jobLinkData);
            imported++;
          }
        } catch (error) {
          errors.push(`Row ${JSON.stringify(row)}: ${error}`);
        }
      }

      return { imported, errors };
    } catch (error) {
      throw new Error(`Failed to import Excel file: ${error}`);
    }
  }

  private static async parseRow(row: any): Promise<CreateJobLinkData | null> {
    // Expected columns: Title, Company, URL, Role, Source, Location, Salary
    const title = row['Title'] || row['Job Title'] || row['title'];
    const company = row['Company'] || row['company'];
    const url = row['URL'] || row['Link'] || row['url'] || row['link'];
    const role = row['Role'] || row['Job Role'] || row['role'];
    const source = row['Source'] || row['source'];
    const location = row['Location'] || row['location'];
    const salary = row['Salary'] || row['Salary Range'] || row['salary'];

    if (!title || !company || !url || !role) {
      throw new Error('Missing required fields: Title, Company, URL, or Role');
    }

    // Find or create role
    const roleId = await this.getOrCreateRole(role);
    
    return {
      title: String(title).trim(),
      company: String(company).trim(),
      url: String(url).trim(),
      role_id: roleId,
      source: source ? String(source).trim() : undefined,
      location: location ? String(location).trim() : undefined,
      salary_range: salary ? String(salary).trim() : undefined
    };
  }

  private static async getOrCreateRole(roleName: string): Promise<number> {
    // First try to find existing role
    const existingRole = await db.get('SELECT id FROM job_roles WHERE name = ?', [roleName]);
    
    if (existingRole) {
      return (existingRole as any).id;
    }

    // Create new role if not found
    const result = await db.run(
      'INSERT INTO job_roles (name) VALUES (?)',
      [roleName]
    );

    return result.lastID;
  }

  static async bulkImport(links: CreateJobLinkData[]): Promise<void> {
    await JobLinkModel.bulkCreate(links);
  }

  static getSupportedFormats(): string[] {
    return ['xlsx', 'xls', 'csv'];
  }
}
