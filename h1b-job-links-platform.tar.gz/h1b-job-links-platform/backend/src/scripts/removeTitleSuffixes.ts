import { Database } from '../models/database';

async function removeTitleSuffixes() {
  const db = new Database();
  
  try {
    console.log('Removing suffixes from existing job titles...');
    
    // Update H1B Sponsored job titles - remove "(H1B Sponsored)" suffix
    const sponsoredResult = await db.run(`
      UPDATE job_links 
      SET title = REPLACE(title, ' (H1B Sponsored)', '') 
      WHERE title LIKE '% (H1B Sponsored)'
    `);
    
    console.log(`✅ Updated ${(sponsoredResult as any).changes} H1B Sponsored job titles`);
    
    // Update F1 Eligible job titles - remove "(F1 Visa Eligible)" suffix
    const f1Result = await db.run(`
      UPDATE job_links 
      SET title = REPLACE(title, ' (F1 Visa Eligible)', '') 
      WHERE title LIKE '% (F1 Visa Eligible)'
    `);
    
    console.log(`✅ Updated ${(f1Result as any).changes} F1 Eligible job titles`);
    
    // Show some examples of updated titles
    const examples = await db.all(`
      SELECT title, job_type 
      FROM job_links 
      WHERE job_type IN ('sponsored', 'f1') 
      LIMIT 5
    `);
    
    console.log('\n📋 Sample updated job titles:');
    examples.forEach((job: any) => {
      console.log(`   - ${job.title} (${job.job_type})`);
    });
    
  } catch (error) {
    console.error('❌ Error removing title suffixes:', error);
    throw error;
  }
}

// Run the script
removeTitleSuffixes()
  .then(() => {
    console.log('🎉 Title suffixes removed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Failed to remove title suffixes:', error);
    process.exit(1);
  });
