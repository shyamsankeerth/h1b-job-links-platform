import { JobLinkModel } from '../models/JobLink';
import { UserModel } from '../models/User';

// Sample data for testing
const sampleJobLinks = [
  {
    title: 'Senior Data Analyst',
    company: 'Google',
    url: 'https://careers.google.com/jobs/results/123456789',
    role_id: 40, // Data Analyst (actual ID from database)
    source: 'Google Careers',
    location: 'Mountain View, CA',
    salary_range: '$120,000 - $150,000'
  },
  {
    title: 'Business Intelligence Analyst',
    company: 'Microsoft',
    url: 'https://careers.microsoft.com/us/en/job/987654321',
    role_id: 39, // Business Analyst (actual ID from database)
    source: 'Microsoft Careers',
    location: 'Seattle, WA',
    salary_range: '$110,000 - $140,000'
  },
  {
    title: 'Full Stack Software Engineer',
    company: 'Amazon',
    url: 'https://amazon.jobs/en/jobs/456789123',
    role_id: 37, // Software Engineer (actual ID from database)
    source: 'Amazon Jobs',
    location: 'Seattle, WA',
    salary_range: '$130,000 - $160,000'
  },
  {
    title: 'Java Backend Developer',
    company: 'Netflix',
    url: 'https://jobs.netflix.com/jobs/789123456',
    role_id: 32, // Java Developer (actual ID from database)
    source: 'Netflix Jobs',
    location: 'Los Gatos, CA',
    salary_range: '$140,000 - $170,000'
  },
  {
    title: 'Python Data Scientist',
    company: 'Facebook',
    url: 'https://www.facebook.com/careers/jobs/321654987',
    role_id: 35, // Python Developer (actual ID from database)
    source: 'Facebook Careers',
    location: 'Menlo Park, CA',
    salary_range: '$135,000 - $165,000'
  }
];

const sampleUsers = [
  {
    email: 'demo@example.com',
    password: 'password123',
    subscription_type: 'premium'
  },
  {
    email: 'test@example.com',
    password: 'password123',
    subscription_type: 'basic'
  }
];

export async function importSampleData() {
  try {
    console.log('Importing sample data...');

    // Create sample users
    for (const userData of sampleUsers) {
      try {
        await UserModel.create(userData);
        console.log(`Created user: ${userData.email}`);
      } catch (error) {
        console.log(`User ${userData.email} already exists`);
      }
    }

    // Create sample job links
    for (const linkData of sampleJobLinks) {
      try {
        await JobLinkModel.create(linkData);
        console.log(`Created job link: ${linkData.title} at ${linkData.company}`);
      } catch (error) {
        console.log(`Job link already exists: ${linkData.title}`);
      }
    }

    console.log('Sample data import completed!');
  } catch (error) {
    console.error('Error importing sample data:', error);
  }
}

// Run if called directly
if (require.main === module) {
  importSampleData().then(() => {
    process.exit(0);
  }).catch((error) => {
    console.error('Import failed:', error);
    process.exit(1);
  });
}
