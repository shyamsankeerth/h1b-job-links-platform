import * as XLSX from 'xlsx';

export function analyzeExcelDetailed() {
  try {
    console.log('Analyzing Excel file structure in detail...');

    // Read the Excel file
    const filePath = './data/H1B_Jobs_By_Role_And_Company (1).xlsx';
    const workbook = XLSX.readFile(filePath);
    
    console.log('Available sheets:', workbook.SheetNames.length);
    console.log('Sheet names:', workbook.SheetNames);
    
    // Analyze the Summary sheet first
    const summarySheet = workbook.Sheets['Summary'];
    if (summarySheet) {
      const summaryData = XLSX.utils.sheet_to_json(summarySheet);
      console.log('\n=== SUMMARY SHEET ===');
      console.log(`Total rows: ${summaryData.length}`);
      console.log('Columns:', Object.keys(summaryData[0] as any));
      console.log('First 5 rows:', summaryData.slice(0, 5));
    }

    // Analyze a few role sheets in detail
    const roleSheets = workbook.SheetNames.filter(name => !name.toLowerCase().includes('summary'));
    
    for (let i = 0; i < Math.min(3, roleSheets.length); i++) {
      const sheetName = roleSheets[i];
      console.log(`\n=== DETAILED ANALYSIS: ${sheetName} ===`);
      
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      if (jsonData.length > 0) {
        console.log(`Total rows: ${jsonData.length}`);
        console.log('Column headers:', Object.keys(jsonData[0] as any));
        
        // Show first few rows with all data
        console.log('\nFirst 3 rows:');
        jsonData.slice(0, 3).forEach((row, index) => {
          console.log(`Row ${index + 1}:`, row);
        });

        // Check for sponsorship data patterns
        const sponsoredYes = jsonData.filter(row => (row as any)['Sponsored Jobs: Yes'] > 0);
        const sponsoredNo = jsonData.filter(row => (row as any)['Sponsored Jobs: No'] > 0);
        const sponsoredUnknown = jsonData.filter(row => (row as any)['Sponsored Jobs: Does not mention'] > 0);
        
        console.log(`\nSponsorship breakdown:`);
        console.log(`- Companies with "Yes": ${sponsoredYes.length}`);
        console.log(`- Companies with "No": ${sponsoredNo.length}`);
        console.log(`- Companies with "Unknown": ${sponsoredUnknown.length}`);
        
        if (sponsoredYes.length > 0) {
          console.log(`\nSample "Yes" row:`, sponsoredYes[0]);
        }
      }
    }

  } catch (error) {
    console.error('Error analyzing Excel structure:', error);
  }
}

// Run if called directly
if (require.main === module) {
  analyzeExcelDetailed();
}
