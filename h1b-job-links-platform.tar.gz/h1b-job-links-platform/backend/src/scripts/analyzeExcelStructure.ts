import * as XLSX from 'xlsx';

export function analyzeExcelStructure() {
  try {
    console.log('Analyzing Excel file structure...');

    // Read the Excel file
    const filePath = './data/H1B_Jobs_By_Role_And_Company (1).xlsx';
    const workbook = XLSX.readFile(filePath);
    
    console.log('Available sheets:', workbook.SheetNames);
    
    // Analyze the first few sheets to understand structure
    for (let i = 0; i < Math.min(3, workbook.SheetNames.length); i++) {
      const sheetName = workbook.SheetNames[i];
      console.log(`\n=== Sheet: ${sheetName} ===`);
      
      const worksheet = workbook.Sheets[sheetName];
      const jsonData = XLSX.utils.sheet_to_json(worksheet);
      
      if (jsonData.length > 0) {
        console.log(`Rows: ${jsonData.length}`);
        console.log('Column headers:', Object.keys(jsonData[0] as any));
        console.log('Sample row 1:', jsonData[0]);
        if (jsonData.length > 1) {
          console.log('Sample row 2:', jsonData[1]);
        }
      } else {
        console.log('No data found');
      }
    }

  } catch (error) {
    console.error('Error analyzing Excel structure:', error);
  }
}

// Run if called directly
if (require.main === module) {
  analyzeExcelStructure();
}
