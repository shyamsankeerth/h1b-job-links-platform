import * as XLSX from 'xlsx';
import { JobLinkModel, CreateJobLinkData } from '../models/JobLink';
import { database } from '../models/database';

const db = database;

// Sample companies for generating job links
const sampleCompanies = [
  'Google', 'Microsoft', 'Amazon', 'Apple', 'Meta', 'Netflix', 'Uber', 'Airbnb',
  'Tesla', 'Spotify', 'Twitter', 'LinkedIn', 'Salesforce', 'Adobe', 'Oracle',
  'IBM', 'Intel', 'Nvidia', 'PayPal', 'Square', 'Stripe', 'Zoom', 'Slack',
  'Dropbox', 'MongoDB', 'Redis', 'GitHub', 'GitLab', 'Docker', 'Kubernetes'
];

// Sample locations
const sampleLocations = [
  'San Francisco, CA', 'Seattle, WA', 'New York, NY', 'Austin, TX',
  'Los Angeles, CA', 'Boston, MA', 'Chicago, IL', 'Denver, CO',
  'Portland, OR', 'Miami, FL', 'Remote', 'Hybrid'
];

// Sample salary ranges
const salaryRanges = [
  '$80,000 - $120,000', '$100,000 - $150,000', '$120,000 - $180,000',
  '$150,000 - $200,000', '$180,000 - $250,000', '$200,000 - $300,000'
];

export async function importRoleData() {
  try {
    console.log('Importing H1B role data and creating sample job links...');

    // Read the Excel file
    const filePath = './data/H1B_Jobs_By_Role_And_Company (1).xlsx';
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    // Convert to JSON
    const jsonData = XLSX.utils.sheet_to_json(worksheet);
    
    console.log(`Found ${jsonData.length} roles in the Excel file`);

    let rolesCreated = 0;
    let jobLinksCreated = 0;

    for (const row of jsonData) {
      try {
        const roleName = (row as any)['Role Name'];
        const totalJobs = (row as any)['Total Jobs'] || 0;
        const sponsoredJobs = (row as any)['Sponsored Jobs: Yes'] || 0;

        if (roleName) {
          // Create or get the role
          const roleId = await getOrCreateRole(String(roleName).trim());
          rolesCreated++;

          // Create sample job links for this role based on the data
          const numLinksToCreate = Math.min(Math.max(1, Math.floor(sponsoredJobs / 10)), 20);
          
          for (let i = 0; i < numLinksToCreate; i++) {
            const jobLink = generateSampleJobLink(roleId, String(roleName).trim());
            await JobLinkModel.create(jobLink);
            jobLinksCreated++;
          }

          console.log(`Created role "${roleName}" with ${numLinksToCreate} sample job links (${sponsoredJobs} sponsored jobs total)`);
        }
      } catch (error) {
        console.error(`Error processing row:`, error);
      }
    }

    console.log(`\nImport completed!`);
    console.log(`- Roles created: ${rolesCreated}`);
    console.log(`- Sample job links created: ${jobLinksCreated}`);
    console.log(`\nYour platform now has real role data with sample job links for each role!`);

    return { rolesCreated, jobLinksCreated };
  } catch (error) {
    console.error('Error importing role data:', error);
    throw error;
  }
}

function generateSampleJobLink(roleId: number, roleName: string): CreateJobLinkData {
  const company = sampleCompanies[Math.floor(Math.random() * sampleCompanies.length)];
  const location = sampleLocations[Math.floor(Math.random() * sampleLocations.length)];
  const salary = salaryRanges[Math.floor(Math.random() * salaryRanges.length)];
  
  // Generate a realistic job title based on the role
  const titlePrefixes = ['Senior', 'Lead', 'Principal', 'Staff', ''];
  const prefix = titlePrefixes[Math.floor(Math.random() * titlePrefixes.length)];
  const title = prefix ? `${prefix} ${roleName}` : roleName;

  // Generate a realistic job URL
  const companyDomain = company.toLowerCase().replace(/\s+/g, '');
  const jobId = Math.floor(Math.random() * 1000000);
  const url = `https://${companyDomain}.com/careers/jobs/${jobId}`;

  return {
    title: title.trim(),
    company,
    url,
    role_id: roleId,
    source: `${company} Careers`,
    location,
    salary_range: salary
  };
}

async function getOrCreateRole(roleName: string): Promise<number> {
  // First try to find existing role
  const existingRole = await db.get('SELECT id FROM job_roles WHERE name = ?', [roleName]);
  
  if (existingRole) {
    return (existingRole as any).id;
  }

  // Create new role if not found
  const result = await db.run(
    'INSERT INTO job_roles (name) VALUES (?)',
    [roleName]
  );

  return result.lastID;
}

// Run if called directly
if (require.main === module) {
  importRoleData().then(() => {
    process.exit(0);
  }).catch((error) => {
    console.error('Import failed:', error);
    process.exit(1);
  });
}
