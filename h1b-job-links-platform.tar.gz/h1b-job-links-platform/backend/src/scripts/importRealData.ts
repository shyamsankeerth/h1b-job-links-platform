import * as XLSX from 'xlsx';
import { JobLinkModel, CreateJobLinkData } from '../models/JobLink';
import { database } from '../models/database';

const db = database;

export async function importRealData() {
  try {
    console.log('Importing real H1B job data...');

    // Read the Excel file
    const filePath = './data/H1B_Jobs_By_Role_And_Company (1).xlsx';
    const workbook = XLSX.readFile(filePath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    
    // Convert to JSON
    const jsonData = XLSX.utils.sheet_to_json(worksheet);
    
    console.log(`Found ${jsonData.length} rows in the Excel file`);
    console.log('Sample row:', jsonData[0]);

    const errors: string[] = [];
    let imported = 0;

    for (const row of jsonData) {
      try {
        const jobLinkData = await parseRow(row);
        if (jobLinkData) {
          await JobLinkModel.create(jobLinkData);
          imported++;
          if (imported % 100 === 0) {
            console.log(`Imported ${imported} job links...`);
          }
        }
      } catch (error) {
        errors.push(`Row ${JSON.stringify(row)}: ${error}`);
        if (errors.length > 10) {
          console.log('Too many errors, stopping...');
          break;
        }
      }
    }

    console.log(`Import completed!`);
    console.log(`- Imported: ${imported} job links`);
    console.log(`- Errors: ${errors.length}`);
    
    if (errors.length > 0) {
      console.log('First few errors:');
      errors.slice(0, 5).forEach(error => console.log(error));
    }

    return { imported, errors };
  } catch (error) {
    console.error('Error importing real data:', error);
    throw error;
  }
}

async function parseRow(row: any): Promise<CreateJobLinkData | null> {
  // Try different possible column names
  const title = row['Title'] || row['Job Title'] || row['title'] || row['JobTitle'] || row['Position'];
  const company = row['Company'] || row['company'] || row['Company Name'] || row['Employer'];
  const url = row['URL'] || row['Link'] || row['url'] || row['link'] || row['Job URL'] || row['JobLink'];
  const role = row['Role'] || row['Job Role'] || row['role'] || row['JobRole'] || row['Position Type'] || row['Category'];
  const source = row['Source'] || row['source'] || row['Job Board'] || row['Platform'];
  const location = row['Location'] || row['location'] || row['City'] || row['State'];
  const salary = row['Salary'] || row['Salary Range'] || row['salary'] || row['Compensation'];

  if (!title || !company || !url || !role) {
    throw new Error(`Missing required fields. Found: title=${!!title}, company=${!!company}, url=${!!url}, role=${!!role}`);
  }

  // Find or create role
  const roleId = await getOrCreateRole(role);
  
  return {
    title: String(title).trim(),
    company: String(company).trim(),
    url: String(url).trim(),
    role_id: roleId,
    source: source ? String(source).trim() : undefined,
    location: location ? String(location).trim() : undefined,
    salary_range: salary ? String(salary).trim() : undefined
  };
}

async function getOrCreateRole(roleName: string): Promise<number> {
  // First try to find existing role
  const existingRole = await db.get('SELECT id FROM job_roles WHERE name = ?', [roleName]);
  
  if (existingRole) {
    return (existingRole as any).id;
  }

  // Create new role if not found
  const result = await db.run(
    'INSERT INTO job_roles (name) VALUES (?)',
    [roleName]
  );

  console.log(`Created new role: ${roleName} (ID: ${result.lastID})`);
  return result.lastID;
}

// Run if called directly
if (require.main === module) {
  importRealData().then(() => {
    process.exit(0);
  }).catch((error) => {
    console.error('Import failed:', error);
    process.exit(1);
  });
}
