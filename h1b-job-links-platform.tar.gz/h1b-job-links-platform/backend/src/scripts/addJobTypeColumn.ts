import { Database } from '../models/database';

async function addJobTypeColumn() {
  const db = new Database();
  
  try {
    console.log('Adding job_type column to job_links table...');
    
    // Add the job_type column
    await db.run(`
      ALTER TABLE job_links ADD COLUMN job_type TEXT DEFAULT 'sponsored'
    `);
    
    console.log('✅ Successfully added job_type column');
    
    // Update existing records based on their titles
    console.log('Updating existing records...');
    
    // Update H1B Sponsored jobs
    await db.run(`
      UPDATE job_links 
      SET job_type = 'sponsored' 
      WHERE title LIKE '%H1B Sponsored%'
    `);
    
    // Update F1 Eligible jobs
    await db.run(`
      UPDATE job_links 
      SET job_type = 'f1' 
      WHERE title LIKE '%F1 Visa Eligible%'
    `);
    
    console.log('✅ Successfully updated existing records with job_type');
    
    // Show statistics
    const sponsoredCount = await db.get('SELECT COUNT(*) as count FROM job_links WHERE job_type = ?', ['sponsored']);
    const f1Count = await db.get('SELECT COUNT(*) as count FROM job_links WHERE job_type = ?', ['f1']);
    
    console.log(`📊 Updated records:`);
    console.log(`   - H1B Sponsored: ${sponsoredCount?.count || 0}`);
    console.log(`   - F1 Eligible: ${f1Count?.count || 0}`);
    
  } catch (error) {
    console.error('❌ Error adding job_type column:', error);
    throw error;
  }
}

// Run the migration
addJobTypeColumn()
  .then(() => {
    console.log('🎉 Migration completed successfully!');
    process.exit(0);
  })
  .catch((error) => {
    console.error('💥 Migration failed:', error);
    process.exit(1);
  });
