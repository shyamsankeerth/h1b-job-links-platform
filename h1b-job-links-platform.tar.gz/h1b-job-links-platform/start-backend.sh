#!/bin/bash

echo "🚀 Starting H1B Job Links Backend..."

# Navigate to backend directory
cd backend

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing backend dependencies..."
    npm install
fi

# Build TypeScript
echo "🔨 Building TypeScript..."
npm run build

# Import sample data
echo "📊 Importing sample data..."
npx ts-node src/scripts/importSampleData.ts

# Start the server
echo "🌟 Starting server on http://localhost:3001"
npm run dev
